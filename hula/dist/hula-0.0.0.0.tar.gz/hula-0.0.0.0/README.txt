Currently Undocumented. 

Experimental learning methods.
